package com.education.leanrbot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
