package com.education.flutter_learbot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
